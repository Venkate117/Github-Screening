package com.palind.binary.services;

public interface BinaryReversalService {

	String getBinaryReversal(Integer input);
}
